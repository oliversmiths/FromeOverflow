PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE monitors (
  id           TEXT PRIMARY KEY,
  label        TEXT,            -- your name for it; the poller never overwrites this
  latitude     REAL,
  longitude    REAL,
  watercourse  TEXT,
  first_seen   INTEGER,
  last_seen    INTEGER
, site_name TEXT, waterbody TEXT, overflow_type TEXT, treatment TEXT, cause TEXT, context_at INTEGER);
INSERT INTO monitors VALUES('WXW00454',NULL,51.23667287452029485,-2.325772866343715162,'RIVER FROME(S)',1788107728322,1788511529240,'FROME WELSHMILL LANE STORM TANKS STORM TANK','Frome (Maiden Bradley to Mells)','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01297',NULL,51.23725752714846493,-2.328754030531561713,'RIVER FROME',1788107728322,1788511529240,'FROME FARRANT ROAD NEAR YOUTH CENTRE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00654',NULL,51.22248074285668196,-2.320356238242214709,'TRIB OF RIVER FROME (VIA SWS)',1788107728322,1788511529240,'FROME LOWER KEYFORD','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00420',NULL,51.22241811128666455,-2.318197738489636617,'ADDERWELL BROOK',1788107728322,1788511529240,'FROME FELTHAM DRIVE NEAR FOOTBRIDGE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00711',NULL,51.23151658696090748,-2.318690206828017076,'RIVER FROME (VIA SWS)',1788107728322,1788511529240,'FROME MERCHANTS BARTON','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00051',NULL,51.23196096940265675,-2.320596862259275195,'RIVER FROME VIA SWS',1788107728322,1788511529240,'FROME SINGERS CATTLE MARKET','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01245',NULL,51.23627957291061819,-2.326200109449961583,'RIVER FROME VIA SWS',1788107728322,1788511529240,'FROME WHATCOMBE ROAD NO 20','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01242',NULL,51.232452799019363,-2.32158982873390185,'RIVER FROME',1788107728322,1788511529240,'FROME WESTWAY PRECINCT CAR PARK R/O','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00062',NULL,51.22335859765986754,-2.312891623999638213,'RIVER FROME (VIA SWS)',1788107728322,1788511529240,'FROME ADDERWELL CLOSE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00880',NULL,51.2287424266873046,-2.30711854072296374,'RIVER FROME',1788107728322,1788511529240,'FROME PORTWAY / LOCKS HILL','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00805',NULL,51.23036785472474719,-2.307987630705505832,'RIVER FROME',1788107728322,1788511529240,'FROME NORTH OF CARPET FACTORY NEAR RAILWAY JUNCTION','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01185',NULL,51.22894219927467674,-2.307124623419493315,'RIVER FROME',1788107728322,1788511529240,'FROME WALLBRIDGE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00934',NULL,51.23198298352310331,-2.312463201725618589,'RIVER FROME(VIA SWS)',1788107728322,1788511529240,'FROME RODDEN ROAD','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00453',NULL,51.23678965608504398,-2.325207064662250911,'RIVER FROME(S)',1788107728322,1788511529240,'FROME WELSHMILL LANE INLET','Frome (Maiden Bradley to Mells)','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00120',NULL,51.2665890964526767,-2.293428501270844855,'RIVER FROME',1788256544235,1788511529240,'BECKINGTON STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00307',NULL,51.23867967299155879,-2.442974661972065587,'MELLS RIVER',1788256544235,1788511529240,'COLEFORD INLET','Mells source to conf with Somerset Frome','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00308',NULL,51.23867967299155879,-2.442974661972065587,'MELLS RIVER',1788256544235,1788511529240,'COLEFORD STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00340',NULL,51.19019872165560514,-2.44052022895809495,'WHATLEY BROOK',1788256544235,1788511529240,'CRANMORE INLET','Whatley Bk - source to conf Mells R','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00401',NULL,51.2370560044534713,-2.470780494255622183,'MELLS RIVER (S)',1788256544235,1788511529240,'EDFORD INLET','Mells source to conf with Somerset Frome','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00402',NULL,51.23703856809265034,-2.470370547225857472,'MELLS RIVER (S)',1788256544235,1788511529240,'EDFORD STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00816',NULL,51.21679784688173242,-2.378972099263463314,'NUNNEY BROOK',1788256544235,1788511529240,'NUNNEY STORM TANK','Nunney Bk - source to conf Mells R','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00936',NULL,51.28973628656940776,-2.282538828925127828,'SOMERSET FROME(S)',1788256544235,1788511529240,'RODE STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW01243',NULL,51.32580657935781688,-2.280884054572305696,'TRIBUTARY OF RIVER FROME',1788256544235,1788511529240,'WESTWOOD STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01272',NULL,51.16939965466654172,-2.364234535958351647,'RIVER FROME',1788256544235,1788511529240,'WITHAM FRIARY','Frome - source to conf Maiden Bradley Bk','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01187',NULL,51.1753085126149685,-2.410958046012670497,' TRIB OF THE NUNNEY BROOK(S)',1788256544235,1788511529240,'WANSTROW','Nunney Bk - source to conf Mells R','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01156',NULL,51.19204881487380731,-2.357551021806588487,'TRIBUTARY OF RIVER FROME',1788256544235,1788511529240,'TRUDOXHILL','Frome - source to conf Maiden Bradley Bk','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00596',NULL,51.23671141235838889,-2.44818118883379432,'MELLS STREAM',1788256544235,1788511529240,'COLEFORD KINGS HEAD','Mells source to conf with Somerset Frome','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00333',NULL,51.23151658696090748,-2.318690206828017076,'RIVER FROME',1788256544235,1788511529240,'FROME COURT HOUSE KING STREET','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00935',NULL,51.28651439296789504,-2.284382684617836112,'TRIB OF THE RIVER FROME',1788256544235,1788511529240,'RODE BARROW FARM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow on sewer network with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00979',NULL,51.33480112153890928,-2.309057702130466349,'RIVER FROME',1788256544235,1788511529240,'FRESHFORD FIELDS OFF ROSEMARY LANE','Somerset Frome conf with Mells to conf B. Avo','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00710',NULL,51.23861757443162901,-2.382554619747745849,'MELLS STREAM',1788256544235,1788511529240,'MELLS STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00709',NULL,51.23931983402514589,-2.387745979055317492,'MELLS STREAM(S)',1788256544235,1788511529240,'MELLS','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01068',NULL,51.22257759307372992,-2.478841020192819489,'TRIB OF MELLS STREAM',1788256544235,1788511529240,'STOKE ST MICHAEL STOKE HILL','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00693',NULL,51.21795291842488495,-2.339517792061502899,'TRIBUTARY OF NUNNEY BROOK',1788256544235,1788511529240,'FROME COURTS BARTON MARSTON LANE','Nunney Bk - source to conf Mells R','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00369',NULL,51.2218504095368985,-2.249228312569295785,'RODDEN BROOK',1788256544235,1788511529240,'CHAPMANSLADE DIVERS BRIDGE','Rodden Bk - source to conf R Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00818',NULL,51.23327151708592452,-2.502039572960814695,'MELLS STREAM',1788262043425,1788511529240,'OAKHILL STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00490',NULL,51.2437835624812621,-2.526573483588950175,'MELLS STREAM(S)',1788262043425,1788511529240,'GURNEY SLADE','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00788',NULL,51.33838070599377801,-2.301523368946631898,'RIVER FROME',1788262043425,1788511529240,'FRESHFORD NEW INN','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE events (
  monitor_id   TEXT NOT NULL,
  start_ms     INTEGER NOT NULL,
  end_ms       INTEGER,         -- NULL while ongoing
  PRIMARY KEY (monitor_id, start_ms)
);
INSERT INTO events VALUES('WXW00454',1788012720000,1788015720000);
INSERT INTO events VALUES('WXW01297',1788011640000,1788012840000);
INSERT INTO events VALUES('WXW00654',1788012000000,1788013560000);
INSERT INTO events VALUES('WXW00420',1787931120000,1787931840000);
INSERT INTO events VALUES('WXW00711',1788012120000,1788012720000);
INSERT INTO events VALUES('WXW00051',1788012000000,1788012360000);
INSERT INTO events VALUES('WXW01245',1788011760000,1788013080000);
INSERT INTO events VALUES('WXW01242',1782149160000,1782149400000);
INSERT INTO events VALUES('WXW00062',1788046560000,1788047280000);
INSERT INTO events VALUES('WXW00880',1787931360000,1787932320000);
INSERT INTO events VALUES('WXW00805',1787931840000,1787932440000);
INSERT INTO events VALUES('WXW01185',1753005120000,1753005600000);
INSERT INTO events VALUES('WXW00934',1782149280000,1782149880000);
INSERT INTO events VALUES('WXW00654',1788145080000,1788145560000);
INSERT INTO events VALUES('WXW01245',1788144240000,1788144480000);
INSERT INTO events VALUES('WXW00062',1788144600000,1788145800000);
INSERT INTO events VALUES('WXW00120',1771451700000,1771451760000);
INSERT INTO events VALUES('WXW00307',1788048240000,1788048360000);
INSERT INTO events VALUES('WXW00308',1788014760000,1788015000000);
INSERT INTO events VALUES('WXW00340',1780355820000,1780356720000);
INSERT INTO events VALUES('WXW00401',1788006060000,1788006120000);
INSERT INTO events VALUES('WXW00402',1782166380000,1782166500000);
INSERT INTO events VALUES('WXW00816',1788027120000,1788036840000);
INSERT INTO events VALUES('WXW00936',1788012240000,1788016200000);
INSERT INTO events VALUES('WXW01243',1782150480000,1782201000000);
INSERT INTO events VALUES('WXW01272',1770745440000,1770753720000);
INSERT INTO events VALUES('WXW01187',1782148860000,1782150480000);
INSERT INTO events VALUES('WXW01156',1788007680000,1788008160000);
INSERT INTO events VALUES('WXW00596',1787220240000,1787220360000);
INSERT INTO events VALUES('WXW00333',1788012000000,1788012720000);
INSERT INTO events VALUES('WXW00935',1766073000000,1766073120000);
INSERT INTO events VALUES('WXW00979',1788027480000,1788027600000);
INSERT INTO events VALUES('WXW01068',1763166480000,1763168280000);
INSERT INTO events VALUES('WXW00120',1771451700010,1771451760010);
INSERT INTO events VALUES('WXW00308',1788014760020,1788015000020);
INSERT INTO events VALUES('WXW00816',1788027120020,1788036840020);
INSERT INTO events VALUES('WXW00818',1782154200020,1782155280020);
INSERT INTO events VALUES('WXW00936',1788012240090,1788016200200);
INSERT INTO events VALUES('WXW01272',1770745440010,1770753720010);
INSERT INTO events VALUES('WXW01187',1782148860010,1782150480010);
INSERT INTO events VALUES('WXW01156',1788007680070,1788008160070);
INSERT INTO events VALUES('WXW00490',1772696700060,1772699520060);
INSERT INTO events VALUES('WXW00788',1763136840000,1763136960000);
INSERT INTO events VALUES('WXW00596',1787220240010,1787220360010);
INSERT INTO events VALUES('WXW00880',1788144240000,1788144600000);
INSERT INTO events VALUES('WXW01068',1763166480010,1763168280010);
INSERT INTO events VALUES('WXW00818',1782154200000,1782155280000);
INSERT INTO events VALUES('WXW00490',1772696700000,1772699520000);
INSERT INTO events VALUES('WXW00420',1787994480000,1787994600000);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE offline (
  monitor_id   TEXT NOT NULL,
  start_ms     INTEGER NOT NULL,
  end_ms       INTEGER,         -- NULL while still offline
  PRIMARY KEY (monitor_id, start_ms)
);
INSERT INTO offline VALUES('WXW00120',1788423323862,1788426046794);
INSERT INTO offline VALUES('WXW01068',1788337834401,1788350444996);
COMMIT;
