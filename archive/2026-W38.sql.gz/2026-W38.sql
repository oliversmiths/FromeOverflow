PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE monitors (
  id           TEXT PRIMARY KEY,
  label        TEXT,            -- your name for it; the poller never overwrites this
  latitude     REAL,
  longitude    REAL,
  watercourse  TEXT,
  first_seen   INTEGER,
  last_seen    INTEGER
, site_name TEXT, waterbody TEXT, overflow_type TEXT, treatment TEXT, cause TEXT, context_at INTEGER);
INSERT INTO monitors VALUES('WXW00454',NULL,51.2366728745202948,-2.32577286634371516,'RIVER FROME(S)',1788107728322,1789344054821,'FROME WELSHMILL LANE STORM TANKS STORM TANK','Frome (Maiden Bradley to Mells)','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01297',NULL,51.2372575271484649,-2.32875403053156171,'RIVER FROME',1788107728322,1789344054821,'FROME FARRANT ROAD NEAR YOUTH CENTRE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00654',NULL,51.2224807428566819,-2.3203562382422147,'TRIB OF RIVER FROME (VIA SWS)',1788107728322,1789344054821,'FROME LOWER KEYFORD','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00420',NULL,51.2224181112866645,-2.31819773848963661,'ADDERWELL BROOK',1788107728322,1789344054821,'FROME FELTHAM DRIVE NEAR FOOTBRIDGE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00711',NULL,51.2315165869609074,-2.31869020682801707,'RIVER FROME (VIA SWS)',1788107728322,1789344054821,'FROME MERCHANTS BARTON','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00051',NULL,51.2319609694026567,-2.32059686225927519,'RIVER FROME VIA SWS',1788107728322,1789344054821,'FROME SINGERS CATTLE MARKET','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01245',NULL,51.2362795729106181,-2.32620010944996158,'RIVER FROME VIA SWS',1788107728322,1789344054821,'FROME WHATCOMBE ROAD NO 20','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01242',NULL,51.232452799019363,-2.32158982873390185,'RIVER FROME',1788107728322,1789344054821,'FROME WESTWAY PRECINCT CAR PARK R/O','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00062',NULL,51.2233585976598675,-2.31289162399963821,'RIVER FROME (VIA SWS)',1788107728322,1789344054821,'FROME ADDERWELL CLOSE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00880',NULL,51.2287424266873046,-2.30711854072296373,'RIVER FROME',1788107728322,1789344054821,'FROME PORTWAY / LOCKS HILL','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00805',NULL,51.2303678547247471,-2.30798763070550583,'RIVER FROME',1788107728322,1789344054821,'FROME NORTH OF CARPET FACTORY NEAR RAILWAY JUNCTION','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01185',NULL,51.2289421992746767,-2.30712462341949331,'RIVER FROME',1788107728322,1789344054821,'FROME WALLBRIDGE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00934',NULL,51.2319829835231033,-2.31246320172561858,'RIVER FROME(VIA SWS)',1788107728322,1789344054821,'FROME RODDEN ROAD','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00453',NULL,51.2367896560850439,-2.32520706466225091,'RIVER FROME(S)',1788107728322,1789344054821,'FROME WELSHMILL LANE INLET','Frome (Maiden Bradley to Mells)','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00120',NULL,51.2665890964526767,-2.29342850127084485,'RIVER FROME',1788256544235,1789344054821,'BECKINGTON STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00307',NULL,51.2386796729915587,-2.44297466197206558,'MELLS RIVER',1788256544235,1789344054821,'COLEFORD INLET','Mells source to conf with Somerset Frome','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00308',NULL,51.2386796729915587,-2.44297466197206558,'MELLS RIVER',1788256544235,1789344054821,'COLEFORD STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00340',NULL,51.1901987216556051,-2.44052022895809495,'WHATLEY BROOK',1788256544235,1789344054821,'CRANMORE INLET','Whatley Bk - source to conf Mells R','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00401',NULL,51.2370560044534712,-2.47078049425562218,'MELLS RIVER (S)',1788256544235,1789344054821,'EDFORD INLET','Mells source to conf with Somerset Frome','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00402',NULL,51.2370385680926503,-2.47037054722585747,'MELLS RIVER (S)',1788256544235,1789344054821,'EDFORD STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00816',NULL,51.2167978468817324,-2.37897209926346331,'NUNNEY BROOK',1788256544235,1789344054821,'NUNNEY STORM TANK','Nunney Bk - source to conf Mells R','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00936',NULL,51.2897362865694077,-2.28253882892512782,'SOMERSET FROME(S)',1788256544235,1789344054821,'RODE STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW01243',NULL,51.3258065793578168,-2.28088405457230569,'TRIBUTARY OF RIVER FROME',1788256544235,1789344054821,'WESTWOOD STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01272',NULL,51.1693996546665417,-2.36423453595835164,'RIVER FROME',1788256544235,1789344054821,'WITHAM FRIARY','Frome - source to conf Maiden Bradley Bk','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01187',NULL,51.1753085126149684,-2.41095804601267049,' TRIB OF THE NUNNEY BROOK(S)',1788256544235,1789344054821,'WANSTROW','Nunney Bk - source to conf Mells R','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01156',NULL,51.1920488148738073,-2.35755102180658848,'TRIBUTARY OF RIVER FROME',1788256544235,1789344054821,'TRUDOXHILL','Frome - source to conf Maiden Bradley Bk','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00596',NULL,51.2367114123583888,-2.44818118883379431,'MELLS STREAM',1788256544235,1789344054821,'COLEFORD KINGS HEAD','Mells source to conf with Somerset Frome','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00333',NULL,51.2315165869609074,-2.31869020682801707,'RIVER FROME',1788256544235,1789344054821,'FROME COURT HOUSE KING STREET','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00935',NULL,51.286514392967895,-2.28438268461783611,'TRIB OF THE RIVER FROME',1788256544235,1789344054821,'RODE BARROW FARM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow on sewer network with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00979',NULL,51.3348011215389092,-2.30905770213046634,'RIVER FROME',1788256544235,1789344054821,'FRESHFORD FIELDS OFF ROSEMARY LANE','Somerset Frome conf with Mells to conf B. Avo','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00710',NULL,51.238617574431629,-2.38255461974774584,'MELLS STREAM',1788256544235,1789344054821,'MELLS STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00709',NULL,51.2393198340251458,-2.38774597905531749,'MELLS STREAM(S)',1788256544235,1789344054821,'MELLS','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01068',NULL,51.2225775930737299,-2.47884102019281948,'TRIB OF MELLS STREAM',1788256544235,1789344054821,'STOKE ST MICHAEL STOKE HILL','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00693',NULL,51.2179529184248849,-2.33951779206150289,'TRIBUTARY OF NUNNEY BROOK',1788256544235,1789344054821,'FROME COURTS BARTON MARSTON LANE','Nunney Bk - source to conf Mells R','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00369',NULL,51.2218504095368984,-2.24922831256929578,'RODDEN BROOK',1788256544235,1789344054821,'CHAPMANSLADE DIVERS BRIDGE','Rodden Bk - source to conf R Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00818',NULL,51.2332715170859245,-2.50203957296081469,'MELLS STREAM',1788262043425,1789344054821,'OAKHILL STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00490',NULL,51.243783562481262,-2.52657348358895017,'MELLS STREAM(S)',1788262043425,1789344054821,'GURNEY SLADE','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00788',NULL,51.338380705993778,-2.30152336894663189,'RIVER FROME',1788262043425,1789344054821,'FRESHFORD NEW INN','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE events (
  monitor_id   TEXT NOT NULL,
  start_ms     INTEGER NOT NULL,
  end_ms       INTEGER,         -- NULL while ongoing
  PRIMARY KEY (monitor_id, start_ms)
);
INSERT INTO events VALUES('WXW00454',1788012720000,1788015720000);
INSERT INTO events VALUES('WXW01297',1788011640000,1788012840000);
INSERT INTO events VALUES('WXW00654',1788012000000,1788013560000);
INSERT INTO events VALUES('WXW00420',1787931120000,1787931840000);
INSERT INTO events VALUES('WXW00711',1788012120000,1788012720000);
INSERT INTO events VALUES('WXW00051',1788012000000,1788012360000);
INSERT INTO events VALUES('WXW01245',1788011760000,1788013080000);
INSERT INTO events VALUES('WXW01242',1782149160000,1782149400000);
INSERT INTO events VALUES('WXW00062',1788046560000,1788047280000);
INSERT INTO events VALUES('WXW00880',1787931360000,1787932320000);
INSERT INTO events VALUES('WXW00805',1787931840000,1787932440000);
INSERT INTO events VALUES('WXW01185',1753005120000,1753005600000);
INSERT INTO events VALUES('WXW00934',1782149280000,1782149880000);
INSERT INTO events VALUES('WXW00654',1788145080000,1788145560000);
INSERT INTO events VALUES('WXW01245',1788144240000,1788144480000);
INSERT INTO events VALUES('WXW00062',1788144600000,1788145800000);
INSERT INTO events VALUES('WXW00120',1771451700000,1771451760000);
INSERT INTO events VALUES('WXW00307',1788048240000,1788048360000);
INSERT INTO events VALUES('WXW00308',1788014760000,1788015000000);
INSERT INTO events VALUES('WXW00340',1780355820000,1780356720000);
INSERT INTO events VALUES('WXW00401',1788006060000,1788006120000);
INSERT INTO events VALUES('WXW00402',1782166380000,1782166500000);
INSERT INTO events VALUES('WXW00816',1788027120000,1788036840000);
INSERT INTO events VALUES('WXW00936',1788012240000,1788016200000);
INSERT INTO events VALUES('WXW01243',1782150480000,1782201000000);
INSERT INTO events VALUES('WXW01272',1770745440000,1770753720000);
INSERT INTO events VALUES('WXW01187',1782148860000,1782150480000);
INSERT INTO events VALUES('WXW01156',1788007680000,1788008160000);
INSERT INTO events VALUES('WXW00596',1787220240000,1787220360000);
INSERT INTO events VALUES('WXW00333',1788012000000,1788012720000);
INSERT INTO events VALUES('WXW00935',1766073000000,1766073120000);
INSERT INTO events VALUES('WXW00979',1788027480000,1788027600000);
INSERT INTO events VALUES('WXW01068',1763166480000,1763168280000);
INSERT INTO events VALUES('WXW00120',1771451700010,1771451760010);
INSERT INTO events VALUES('WXW00308',1788014760020,1788015000020);
INSERT INTO events VALUES('WXW00816',1788027120020,1788036840020);
INSERT INTO events VALUES('WXW00818',1782154200020,1782155280020);
INSERT INTO events VALUES('WXW00936',1788012240090,1788016200200);
INSERT INTO events VALUES('WXW01272',1770745440010,1770753720010);
INSERT INTO events VALUES('WXW01187',1782148860010,1782150480010);
INSERT INTO events VALUES('WXW01156',1788007680070,1788008160070);
INSERT INTO events VALUES('WXW00490',1772696700060,1772699520060);
INSERT INTO events VALUES('WXW00788',1763136840000,1763136960000);
INSERT INTO events VALUES('WXW00596',1787220240010,1787220360010);
INSERT INTO events VALUES('WXW00880',1788144240000,1788144600000);
INSERT INTO events VALUES('WXW01068',1763166480010,1763168280010);
INSERT INTO events VALUES('WXW00818',1782154200000,1782155280000);
INSERT INTO events VALUES('WXW00490',1772696700000,1772699520000);
INSERT INTO events VALUES('WXW00420',1787994480000,1787994600000);
INSERT INTO events VALUES('WXW00979',1788851880000,1788852000000);
INSERT INTO events VALUES('WXW00979',1788852840000,1788853080000);
INSERT INTO events VALUES('WXW00307',1788010320000,1788010440000);
INSERT INTO events VALUES('WXW00979',1788862560000,1788862920000);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE offline (
  monitor_id   TEXT NOT NULL,
  start_ms     INTEGER NOT NULL,
  end_ms       INTEGER,         -- NULL while still offline
  PRIMARY KEY (monitor_id, start_ms)
);
INSERT INTO offline VALUES('WXW00120',1788423323862,1788426046794);
INSERT INTO offline VALUES('WXW01068',1788337834401,1788350444996);
INSERT INTO offline VALUES('WXW00490',1788852643971,1788853534041);
INSERT INTO offline VALUES('WXW00490',1788853534041,1788854449686);
INSERT INTO offline VALUES('WXW00490',1788854449686,1788855329416);
INSERT INTO offline VALUES('WXW00490',1788855329416,1788856238281);
INSERT INTO offline VALUES('WXW00490',1788856238281,1788857128800);
INSERT INTO offline VALUES('WXW00490',1788857128800,1788858120762);
INSERT INTO offline VALUES('WXW00490',1788858120762,1788858930861);
INSERT INTO offline VALUES('WXW00490',1788858930861,1772699520000);
INSERT INTO offline VALUES('WXW00816',1789037129253,1789038049860);
INSERT INTO offline VALUES('WXW00816',1789038049860,1789038765743);
INSERT INTO offline VALUES('WXW00816',1789038765743,1789038926795);
INSERT INTO offline VALUES('WXW00816',1789038926795,1789039840983);
INSERT INTO offline VALUES('WXW00816',1789039840983,1788036840020);
INSERT INTO offline VALUES('WXW01297',1789133442212,1789134329563);
INSERT INTO offline VALUES('WXW01297',1789134329563,1789135253501);
INSERT INTO offline VALUES('WXW01297',1789135253501,1789136134515);
INSERT INTO offline VALUES('WXW01297',1789136134515,1789137042724);
INSERT INTO offline VALUES('WXW01297',1789137042724,1789137929169);
INSERT INTO offline VALUES('WXW01297',1789137929169,1789138853412);
INSERT INTO offline VALUES('WXW01297',1789138853412,1789139109480);
INSERT INTO offline VALUES('WXW01297',1789139109480,1789139732814);
INSERT INTO offline VALUES('WXW01297',1789139732814,1789140644781);
INSERT INTO offline VALUES('WXW01297',1789140644781,1789141531530);
INSERT INTO offline VALUES('WXW01297',1789141531530,1789142453406);
INSERT INTO offline VALUES('WXW01297',1789142453406,1789143332583);
INSERT INTO offline VALUES('WXW01297',1789143332583,1789144243135);
INSERT INTO offline VALUES('WXW01297',1789144243135,1788012840000);
COMMIT;
