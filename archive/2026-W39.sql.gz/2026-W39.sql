PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE monitors (
  id           TEXT PRIMARY KEY,
  label        TEXT,            -- your name for it; the poller never overwrites this
  latitude     REAL,
  longitude    REAL,
  watercourse  TEXT,
  first_seen   INTEGER,
  last_seen    INTEGER
, site_name TEXT, waterbody TEXT, overflow_type TEXT, treatment TEXT, cause TEXT, context_at INTEGER);
INSERT INTO monitors VALUES('WXW00454',NULL,51.2366728745202948,-2.32577286634371516,'RIVER FROME(S)',1788107728322,1789948849126,'FROME WELSHMILL LANE STORM TANKS STORM TANK','Frome (Maiden Bradley to Mells)','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01297',NULL,51.2372575271484649,-2.32875403053156171,'RIVER FROME',1788107728322,1789948849126,'FROME FARRANT ROAD NEAR YOUTH CENTRE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00654',NULL,51.2224807428566819,-2.3203562382422147,'TRIB OF RIVER FROME (VIA SWS)',1788107728322,1789948849126,'FROME LOWER KEYFORD','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00420',NULL,51.2224181112866645,-2.31819773848963661,'ADDERWELL BROOK',1788107728322,1789948849126,'FROME FELTHAM DRIVE NEAR FOOTBRIDGE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00711',NULL,51.2315165869609074,-2.31869020682801707,'RIVER FROME (VIA SWS)',1788107728322,1789948849126,'FROME MERCHANTS BARTON','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00051',NULL,51.2319609694026567,-2.32059686225927519,'RIVER FROME VIA SWS',1788107728322,1789948849126,'FROME SINGERS CATTLE MARKET','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01245',NULL,51.2362795729106181,-2.32620010944996158,'RIVER FROME VIA SWS',1788107728322,1789948849126,'FROME WHATCOMBE ROAD NO 20','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01242',NULL,51.232452799019363,-2.32158982873390185,'RIVER FROME',1788107728322,1789948849126,'FROME WESTWAY PRECINCT CAR PARK R/O','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00062',NULL,51.2233585976598675,-2.31289162399963821,'RIVER FROME (VIA SWS)',1788107728322,1789948849126,'FROME ADDERWELL CLOSE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00880',NULL,51.2287424266873046,-2.30711854072296373,'RIVER FROME',1788107728322,1789948849126,'FROME PORTWAY / LOCKS HILL','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00805',NULL,51.2303678547247471,-2.30798763070550583,'RIVER FROME',1788107728322,1789948849126,'FROME NORTH OF CARPET FACTORY NEAR RAILWAY JUNCTION','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01185',NULL,51.2289421992746767,-2.30712462341949331,'RIVER FROME',1788107728322,1789948849126,'FROME WALLBRIDGE','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00934',NULL,51.2319829835231033,-2.31246320172561858,'RIVER FROME(VIA SWS)',1788107728322,1789948849126,'FROME RODDEN ROAD','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00453',NULL,51.2367896560850439,-2.32520706466225091,'RIVER FROME(S)',1788107728322,1789948849126,'FROME WELSHMILL LANE INLET','Frome (Maiden Bradley to Mells)','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00120',NULL,51.2665890964526767,-2.29342850127084485,'RIVER FROME',1788256544235,1789948849126,'BECKINGTON STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00307',NULL,51.2386796729915587,-2.44297466197206558,'MELLS RIVER',1788256544235,1789948849126,'COLEFORD INLET','Mells source to conf with Somerset Frome','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00308',NULL,51.2386796729915587,-2.44297466197206558,'MELLS RIVER',1788256544235,1789948849126,'COLEFORD STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00340',NULL,51.1901987216556051,-2.44052022895809495,'WHATLEY BROOK',1788256544235,1789948849126,'CRANMORE INLET','Whatley Bk - source to conf Mells R','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00401',NULL,51.2370560044534712,-2.47078049425562218,'MELLS RIVER (S)',1788256544235,1789948849126,'EDFORD INLET','Mells source to conf with Somerset Frome','Storm overflow at inlet of water recycling centre','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00402',NULL,51.2370385680926503,-2.47037054722585747,'MELLS RIVER (S)',1788256544235,1789948849126,'EDFORD STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00816',NULL,51.2167978468817324,-2.37897209926346331,'NUNNEY BROOK',1788256544235,1789948849126,'NUNNEY STORM TANK','Nunney Bk - source to conf Mells R','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00936',NULL,51.2897362865694077,-2.28253882892512782,'SOMERSET FROME(S)',1788256544235,1789948849126,'RODE STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW01243',NULL,51.3258065793578168,-2.28088405457230569,'TRIBUTARY OF RIVER FROME',1788256544235,1789948849126,'WESTWOOD STORM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01272',NULL,51.1693996546665417,-2.36423453595835164,'RIVER FROME',1788256544235,1789948849126,'WITHAM FRIARY','Frome - source to conf Maiden Bradley Bk','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01187',NULL,51.1753085126149684,-2.41095804601267049,' TRIB OF THE NUNNEY BROOK(S)',1788256544235,1789948849126,'WANSTROW','Nunney Bk - source to conf Mells R','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01156',NULL,51.1920488148738073,-2.35755102180658848,'TRIBUTARY OF RIVER FROME',1788256544235,1789948849126,'TRUDOXHILL','Frome - source to conf Maiden Bradley Bk','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00596',NULL,51.2367114123583888,-2.44818118883379431,'MELLS STREAM',1788256544235,1789948849126,'COLEFORD KINGS HEAD','Mells source to conf with Somerset Frome','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00333',NULL,51.2315165869609074,-2.31869020682801707,'RIVER FROME',1788256544235,1789948849126,'FROME COURT HOUSE KING STREET','Frome (Maiden Bradley to Mells)','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00935',NULL,51.286514392967895,-2.28438268461783611,'TRIB OF THE RIVER FROME',1788256544235,1789948849126,'RODE BARROW FARM TANK','Somerset Frome conf with Mells to conf B. Avo','Storm overflow on sewer network with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00979',NULL,51.3348011215389092,-2.30905770213046634,'RIVER FROME',1788256544235,1789948849126,'FRESHFORD FIELDS OFF ROSEMARY LANE','Somerset Frome conf with Mells to conf B. Avo','Storm overflow on sewer network','Diluted (sewage diluted by rainwater or groundwater)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00710',NULL,51.238617574431629,-2.38255461974774584,'MELLS STREAM',1788256544235,1789948849126,'MELLS STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00709',NULL,51.2393198340251458,-2.38774597905531749,'MELLS STREAM(S)',1788256544235,1789948849126,'MELLS','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW01068',NULL,51.2225775930737299,-2.47884102019281948,'TRIB OF MELLS STREAM',1788256544235,1789948849126,'STOKE ST MICHAEL STOKE HILL','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater',1788453457812);
INSERT INTO monitors VALUES('WXW00693',NULL,51.2179529184248849,-2.33951779206150289,'TRIBUTARY OF NUNNEY BROOK',1788256544235,1789948849126,'FROME COURTS BARTON MARSTON LANE','Nunney Bk - source to conf Mells R','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00369',NULL,51.2218504095368984,-2.24922831256929578,'RODDEN BROOK',1788256544235,1789948849126,'CHAPMANSLADE DIVERS BRIDGE','Rodden Bk - source to conf R Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00818',NULL,51.2332715170859245,-2.50203957296081469,'MELLS STREAM',1788262043425,1789948849126,'OAKHILL STORM TANK','Mells source to conf with Somerset Frome','Storm overflow at water recycling centre after settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00490',NULL,51.243783562481262,-2.52657348358895017,'MELLS STREAM(S)',1788262043425,1789948849126,'GURNEY SLADE','Mells source to conf with Somerset Frome','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','When the surrounding water table is high, this overflow is known to be affected by groundwater.  At other times, the overflow discharges due to rainwater entering the sewer',1788453457812);
INSERT INTO monitors VALUES('WXW00788',NULL,51.338380705993778,-2.30152336894663189,'RIVER FROME',1788262043425,1789948849126,'FRESHFORD NEW INN','Somerset Frome conf with Mells to conf B. Avo','Storm overflow at pumping station with settlement treatment','Diluted and partially treated (e.g. sewage diluted by rainwater or groundwater, and settled in storage tanks prior to discharge)','This overflow discharges primarily in response to rainwater entering the sewer',1788453457812);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE events (
  monitor_id   TEXT NOT NULL,
  start_ms     INTEGER NOT NULL,
  end_ms       INTEGER,         -- NULL while ongoing
  PRIMARY KEY (monitor_id, start_ms)
);
INSERT INTO events VALUES('WXW00454',1788012720000,1788015720000);
INSERT INTO events VALUES('WXW01297',1788011640000,1788012840000);
INSERT INTO events VALUES('WXW00654',1788012000000,1788013560000);
INSERT INTO events VALUES('WXW00420',1787931120000,1787931840000);
INSERT INTO events VALUES('WXW00711',1788012120000,1788012720000);
INSERT INTO events VALUES('WXW00051',1788012000000,1788012360000);
INSERT INTO events VALUES('WXW01245',1788011760000,1788013080000);
INSERT INTO events VALUES('WXW01242',1782149160000,1782149400000);
INSERT INTO events VALUES('WXW00062',1788046560000,1788047280000);
INSERT INTO events VALUES('WXW00880',1787931360000,1787932320000);
INSERT INTO events VALUES('WXW00805',1787931840000,1787932440000);
INSERT INTO events VALUES('WXW01185',1753005120000,1753005600000);
INSERT INTO events VALUES('WXW00934',1782149280000,1782149880000);
INSERT INTO events VALUES('WXW00654',1788145080000,1788145560000);
INSERT INTO events VALUES('WXW01245',1788144240000,1788144480000);
INSERT INTO events VALUES('WXW00062',1788144600000,1788145800000);
INSERT INTO events VALUES('WXW00120',1771451700000,1771451760000);
INSERT INTO events VALUES('WXW00307',1788048240000,1788048360000);
INSERT INTO events VALUES('WXW00308',1788014760000,1788015000000);
INSERT INTO events VALUES('WXW00340',1780355820000,1780356720000);
INSERT INTO events VALUES('WXW00401',1788006060000,1788006120000);
INSERT INTO events VALUES('WXW00402',1782166380000,1782166500000);
INSERT INTO events VALUES('WXW00816',1788027120000,1788036840000);
INSERT INTO events VALUES('WXW00936',1788012240000,1788016200000);
INSERT INTO events VALUES('WXW01243',1782150480000,1782201000000);
INSERT INTO events VALUES('WXW01272',1770745440000,1770753720000);
INSERT INTO events VALUES('WXW01187',1782148860000,1782150480000);
INSERT INTO events VALUES('WXW01156',1788007680000,1788008160000);
INSERT INTO events VALUES('WXW00596',1787220240000,1787220360000);
INSERT INTO events VALUES('WXW00333',1788012000000,1788012720000);
INSERT INTO events VALUES('WXW00935',1766073000000,1766073120000);
INSERT INTO events VALUES('WXW00979',1788027480000,1788027600000);
INSERT INTO events VALUES('WXW01068',1763166480000,1763168280000);
INSERT INTO events VALUES('WXW00120',1771451700010,1771451760010);
INSERT INTO events VALUES('WXW00308',1788014760020,1788015000020);
INSERT INTO events VALUES('WXW00816',1788027120020,1788036840020);
INSERT INTO events VALUES('WXW00818',1782154200020,1782155280020);
INSERT INTO events VALUES('WXW00936',1788012240090,1788016200200);
INSERT INTO events VALUES('WXW01272',1770745440010,1770753720010);
INSERT INTO events VALUES('WXW01187',1782148860010,1782150480010);
INSERT INTO events VALUES('WXW01156',1788007680070,1788008160070);
INSERT INTO events VALUES('WXW00490',1772696700060,1772699520060);
INSERT INTO events VALUES('WXW00788',1763136840000,1763136960000);
INSERT INTO events VALUES('WXW00596',1787220240010,1787220360010);
INSERT INTO events VALUES('WXW00880',1788144240000,1788144600000);
INSERT INTO events VALUES('WXW01068',1763166480010,1763168280010);
INSERT INTO events VALUES('WXW00818',1782154200000,1782155280000);
INSERT INTO events VALUES('WXW00490',1772696700000,1772699520000);
INSERT INTO events VALUES('WXW00420',1787994480000,1787994600000);
INSERT INTO events VALUES('WXW00979',1788851880000,1788852000000);
INSERT INTO events VALUES('WXW00979',1788852840000,1788853080000);
INSERT INTO events VALUES('WXW00307',1788010320000,1788010440000);
INSERT INTO events VALUES('WXW00979',1788862560000,1788862920000);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE offline (
  monitor_id   TEXT NOT NULL,
  start_ms     INTEGER NOT NULL,
  end_ms       INTEGER,         -- NULL while still offline
  PRIMARY KEY (monitor_id, start_ms)
);
INSERT INTO offline VALUES('WXW00120',1788423323862,1788426046794);
INSERT INTO offline VALUES('WXW01068',1788337834401,1788350444996);
INSERT INTO offline VALUES('WXW00490',1788852643971,1788853534041);
INSERT INTO offline VALUES('WXW00490',1788853534041,1788854449686);
INSERT INTO offline VALUES('WXW00490',1788854449686,1788855329416);
INSERT INTO offline VALUES('WXW00490',1788855329416,1788856238281);
INSERT INTO offline VALUES('WXW00490',1788856238281,1788857128800);
INSERT INTO offline VALUES('WXW00490',1788857128800,1788858120762);
INSERT INTO offline VALUES('WXW00490',1788858120762,1788858930861);
INSERT INTO offline VALUES('WXW00490',1788858930861,1772699520000);
INSERT INTO offline VALUES('WXW00816',1789037129253,1789038049860);
INSERT INTO offline VALUES('WXW00816',1789038049860,1789038765743);
INSERT INTO offline VALUES('WXW00816',1789038765743,1789038926795);
INSERT INTO offline VALUES('WXW00816',1789038926795,1789039840983);
INSERT INTO offline VALUES('WXW00816',1789039840983,1788036840020);
INSERT INTO offline VALUES('WXW01297',1789133442212,1789134329563);
INSERT INTO offline VALUES('WXW01297',1789134329563,1789135253501);
INSERT INTO offline VALUES('WXW01297',1789135253501,1789136134515);
INSERT INTO offline VALUES('WXW01297',1789136134515,1789137042724);
INSERT INTO offline VALUES('WXW01297',1789137042724,1789137929169);
INSERT INTO offline VALUES('WXW01297',1789137929169,1789138853412);
INSERT INTO offline VALUES('WXW01297',1789138853412,1789139109480);
INSERT INTO offline VALUES('WXW01297',1789139109480,1789139732814);
INSERT INTO offline VALUES('WXW01297',1789139732814,1789140644781);
INSERT INTO offline VALUES('WXW01297',1789140644781,1789141531530);
INSERT INTO offline VALUES('WXW01297',1789141531530,1789142453406);
INSERT INTO offline VALUES('WXW01297',1789142453406,1789143332583);
INSERT INTO offline VALUES('WXW01297',1789143332583,1789144243135);
INSERT INTO offline VALUES('WXW01297',1789144243135,1788012840000);
INSERT INTO offline VALUES('WXW01068',1789551929374,1789552850274);
INSERT INTO offline VALUES('WXW01068',1789552850274,1789552994532);
INSERT INTO offline VALUES('WXW01068',1789552994532,1789553727118);
INSERT INTO offline VALUES('WXW01068',1789553727118,1789554641548);
INSERT INTO offline VALUES('WXW01068',1789554641548,1789555530101);
INSERT INTO offline VALUES('WXW01068',1789555530101,1789557326911);
INSERT INTO offline VALUES('WXW01068',1789557326911,1789558239370);
INSERT INTO offline VALUES('WXW01068',1789558239370,1789559127576);
INSERT INTO offline VALUES('WXW01068',1789559127576,1789560056406);
INSERT INTO offline VALUES('WXW01068',1789560056406,1789560926397);
INSERT INTO offline VALUES('WXW01068',1789560926397,1789561839094);
INSERT INTO offline VALUES('WXW01068',1789561839094,1789562727857);
INSERT INTO offline VALUES('WXW01068',1789562727857,1789563651425);
INSERT INTO offline VALUES('WXW01068',1789563651425,1789564566019);
INSERT INTO offline VALUES('WXW01068',1789564566019,1789565443873);
INSERT INTO offline VALUES('WXW01068',1789565443873,1789566327157);
INSERT INTO offline VALUES('WXW01068',1789566327157,1789567260786);
INSERT INTO offline VALUES('WXW01068',1789567260786,1789568129179);
INSERT INTO offline VALUES('WXW01068',1789568129179,1789569043045);
INSERT INTO offline VALUES('WXW01068',1789569043045,1789569928642);
INSERT INTO offline VALUES('WXW01068',1789569928642,1789570379352);
INSERT INTO offline VALUES('WXW01068',1789570379352,1789570851493);
INSERT INTO offline VALUES('WXW01068',1789570851493,1763168280010);
INSERT INTO offline VALUES('WXW01243',1789633838261,1789634727373);
INSERT INTO offline VALUES('WXW01243',1789634727373,1789635648846);
INSERT INTO offline VALUES('WXW01243',1789635648846,1789636531835);
INSERT INTO offline VALUES('WXW01243',1789636531835,1789637441370);
INSERT INTO offline VALUES('WXW01243',1789637441370,1789638057541);
INSERT INTO offline VALUES('WXW01243',1789638057541,1789638328614);
INSERT INTO offline VALUES('WXW01243',1789638328614,1789639248284);
INSERT INTO offline VALUES('WXW01243',1789639248284,1789640132183);
INSERT INTO offline VALUES('WXW01243',1789640132183,1789641043389);
INSERT INTO offline VALUES('WXW01243',1789641043389,1782201000000);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE annual_returns (
  monitor_id           TEXT NOT NULL,
  year                 INTEGER NOT NULL,
  spill_count          INTEGER,      -- 12-24h counted spills for that year
  duration_hours       REAL,         -- total spill duration that year, hours
  long_term_avg_spills REAL,         -- avg annual spill count, data_start_year..year
  data_start_year      INTEGER,      -- first year behind the long-term average
  fetched_at           INTEGER NOT NULL,
  PRIMARY KEY (monitor_id, year)
);
INSERT INTO annual_returns VALUES('WXW00788',2024,16,81.0,6.66666650772094726,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00805',2024,5,1.36666667461395263,8.14285755157470703,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00816',2024,81,1245.25,62.1666679382324218,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00818',2024,23,214.838577270507812,8.83333301544189453,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00880',2024,19,5.26666688919067382,17.0,2023,1789556796685);
INSERT INTO annual_returns VALUES('WXW00934',2024,5,8.03333377838134765,17.1428565979003906,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00935',2024,5,30.1000003814697265,3.57142853736877441,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00936',2024,82,1146.7781982421875,46.8888893127441406,2016,1789556796685);
INSERT INTO annual_returns VALUES('WXW00979',2024,67,165.466659545898437,38.4285697937011718,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW01068',2024,11,81.75,7.66666650772094726,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW01156',2024,81,843.2833251953125,54.0,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW01185',2024,6,22.4666671752929687,5.57142877578735351,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW01187',2024,27,140.616668701171875,16.5,2021,1789556796685);
INSERT INTO annual_returns VALUES('WXW01242',2024,2,0.266666680574417114,28.7142848968505859,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW01243',2024,62,1037.25,30.5714282989501953,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW01245',2024,45,25.0666675567626953,37.2857131958007812,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW01272',2024,37,341.75,18.1428565979003906,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW01297',2024,40,16.2000007629394531,35.2857131958007812,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00401',2025,46,218.675003051757812,63.6666679382324218,2023,1789556796685);
INSERT INTO annual_returns VALUES('WXW00402',2025,46,366.186798095703125,68.0,2023,1789556796685);
INSERT INTO annual_returns VALUES('WXW00454',2025,22,60.0996551513671875,27.0,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW00453',2025,0,0.0,7.83333349227905273,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW01242',2025,3,0.166800007224082946,25.285715103149414,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00333',2025,19,5.56608009338378906,28.1428565979003906,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW01156',2025,53,584.33367919921875,54.6666679382324218,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW00711',2025,17,4.33266687393188476,21.5,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW01187',2025,16,122.933441162109375,20.5,2022,1789556796685);
INSERT INTO annual_returns VALUES('WXW01272',2025,17,163.099899291992187,20.5714282989501953,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00934',2025,2,2.19989323616027832,13.8571424484252929,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00880',2025,17,2.16554665565490722,18.0,2024,1789556796685);
INSERT INTO annual_returns VALUES('WXW00420',2025,13,0.566373348236083984,15.4285717010498046,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00490',2025,19,95.116424560546875,36.1428565979003906,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW01245',2025,31,10.2326135635375976,38.0,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00340',2025,37,422.372406005859375,50.6666679382324218,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW01243',2025,30,421.0333251953125,34.8571434020996093,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW01297',2025,21,6.83365345001220703,36.5714302062988281,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00307',2025,42,162.232772827148437,39.125,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00308',2025,73,779.5479736328125,95.25,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00816',2025,77,1382.8017578125,72.0,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW00120',2025,11,131.5999755859375,31.3333339691162109,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW00936',2025,39,522.283447265625,65.8571395874023437,2017,1789556796685);
INSERT INTO annual_returns VALUES('WXW00051',2024,9,2.46666669845581054,11.4285717010498046,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00062',2024,72,175.600006103515625,63.2857131958007812,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00120',2024,55,853.79998779296875,33.0,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00307',2024,59,242.033340454101562,33.875,2017,1789556796685);
INSERT INTO annual_returns VALUES('WXW00308',2024,98,1441.5,86.125,2017,1789556796685);
INSERT INTO annual_returns VALUES('WXW00333',2024,35,13.3666667938232421,28.7142848968505859,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00340',2024,60,539.22796630859375,38.1428565979003906,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00369',2024,16,151.4647216796875,8.5,2023,1789556796685);
INSERT INTO annual_returns VALUES('WXW00710',2025,0,0.0,14.7142858505249023,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00051',2025,6,1.09976005554199218,11.8571424484252929,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW01068',2025,1,7.40015983581542968,7.83333349227905273,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW00818',2025,5,30.3336315155029296,9.5,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW00369',2025,2,14.7408332824707031,9.0,2024,1789556796685);
INSERT INTO annual_returns VALUES('WXW00805',2025,4,0.633333325386047363,6.42857122421264648,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00788',2025,4,13.6667203903198242,7.19999980926513671,2020,1789556796685);
INSERT INTO annual_returns VALUES('WXW01185',2025,3,11.4331998825073242,5.42857122421264648,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00935',2025,3,7.06669330596923828,4.0,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00596',2025,26,76.8839187622070312,40.5714302062988281,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00654',2025,58,81.198455810546875,61.5714302062988281,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00062',2025,58,106.764823913574218,63.0,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00709',2025,0,0.0,2.28571438789367675,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00401',2024,68,385.220733642578125,58.0,2022,1789556796685);
INSERT INTO annual_returns VALUES('WXW00402',2024,61,657.41668701171875,65.3333358764648437,2022,1789556796685);
INSERT INTO annual_returns VALUES('WXW00420',2024,5,0.466666668653488159,16.8571434020996093,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00453',2024,2,3.8166666030883789,7.83333349227905273,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00454',2024,43,153.199996948242187,23.3333339691162109,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00490',2024,65,990.433349609375,33.4285697937011718,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00596',2024,55,198.5,41.4285697937011718,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00654',2024,69,154.0,61.5714302062988281,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00693',2024,0,0.0,0.0,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00709',2024,4,23.8500003814697265,2.28571438789367675,2018,1789556796685);
INSERT INTO annual_returns VALUES('WXW00710',2024,2,23.2999992370605468,13.875,2017,1789556796685);
INSERT INTO annual_returns VALUES('WXW00711',2024,35,10.5666666030883789,19.5,2017,1789556796685);
INSERT INTO annual_returns VALUES('WXW00979',2025,29,63.2332000732421875,49.6666679382324218,2019,1789556796685);
INSERT INTO annual_returns VALUES('WXW00693',2025,0,0.0,0.0,2020,1789556796685);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE swim_spots (
  id               TEXT PRIMARY KEY,
  name             TEXT NOT NULL,
  latitude         REAL NOT NULL,
  longitude        REAL NOT NULL,
  recognised       INTEGER NOT NULL,   -- 1 = an EA/Wessex-recognised bathing spot, 0 = just popular
  description      TEXT,
  dashboard_url    TEXT,
  flow_value       REAL,               -- latest Tellisford gauge reading, m3/s -- shared context
  flow_measured_at INTEGER,            -- for every spot on this reach, not just the one nearest the gauge
  fetched_at       INTEGER NOT NULL
);
INSERT INTO swim_spots VALUES('farleigh-hungerford','Farleigh Hungerford',51.3178300000000007,-2.28194000000000007,1,'A recognised bathing spot on the Frome, sampled weekly through the season.','https://www.arcgis.com/apps/dashboards/a058553168f44f02905dd0b9dd667875',0.621999999999999997,1788771600000,1789935330904);
INSERT INTO swim_spots VALUES('tellisford-weir','Tellisford Weir',51.2978009999999997,-2.28082299999999982,0,'A popular spot on the Frome, just upstream of Farleigh Hungerford — not an officially recognised bathing water, so no water quality sampling here.',NULL,0.621999999999999997,1788771600000,1789935330904);
COMMIT;
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE swim_spot_readings (
  spot_id     TEXT NOT NULL,
  determinand TEXT NOT NULL,
  result      REAL,
  units       TEXT,
  status      TEXT,           -- Wessex's own plain-English line for that sampling date
  sampled_at  INTEGER NOT NULL,
  PRIMARY KEY (spot_id, determinand, sampled_at)
);
INSERT INTO swim_spot_readings VALUES('farleigh-hungerford','E coli',170.0,'E. Coli/ 100 mL','11/08/2026 show excellent indicative water quality at this location.',1786441800000);
INSERT INTO swim_spot_readings VALUES('farleigh-hungerford','Enterococci',66.0,'Enterococci/ 100 mL','11/08/2026 show excellent indicative water quality at this location.',1786441800000);
INSERT INTO swim_spot_readings VALUES('farleigh-hungerford','E coli',820.0,'E. Coli/ 100 mL','08/09/2026 show below good indicative water quality at this location.',1788869700000);
INSERT INTO swim_spot_readings VALUES('farleigh-hungerford','Enterococci',7500.0,'Enterococci/ 100 mL','08/09/2026 show below good indicative water quality at this location.',1788869700000);
COMMIT;
